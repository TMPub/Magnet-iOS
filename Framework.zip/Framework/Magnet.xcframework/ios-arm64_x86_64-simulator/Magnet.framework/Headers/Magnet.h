//
//  Magnet.h
//  Magnet
//
//  Created by Magnet on 2022/6/29.
//

#ifndef Magnet_h
#define Magnet_h

#import "MTAdManager.h"
#import "MTNativeAdLoader.h"
#import "MTBannerAdLoader.h"
#import "MTInterstitialAdLoader.h"
#import "MTRewardAdLoader.h"
#import "MTAppOpenAdLoader.h"
#import "MTNativeAdView.h"
#import "MTBannerView.h"
#import "MTMediaView.h"
#import "MTNativeAd.h"
#import "MTAdSpace.h"
#import "MTAdSource.h"
#import "MTAdDefine.h"

#endif /* Magnet_h */
